# judgethesituation-analytics

Shared, typed gameplay analytics for Judge the Situation games.

## Install from GitHub

Until this package is published to npm, install a release tarball or GitHub package repository:

```bash
npm install judgethesituation-analytics
```

## Use

```ts
import { createGameAnalytics } from "judgethesituation-analytics";

export const analytics = createGameAnalytics({
  gameSlug: "the-yield-trap",
  gameVersion: "1.0.0",
  debug: process.env.NODE_ENV !== "production",
});
```

In client-side gameplay handlers:

```ts
analytics.trackOnce("landing_view");
analytics.trackOnce("game_impression");
analytics.track("game_start");
analytics.track("first_decision", { round_number: 1, choice_id: "hold" });
analytics.track("round_complete", { round_number: 2, choice_id: "intervene" });
analytics.track("game_complete", { score: 74, ending: "soft_landing" });
analytics.track("result_view", { score: 74 });
```

Call `analytics.newSession()` immediately before a replay begins. The SDK automatically supplies event IDs, visitor and session IDs, campaign attribution, sequence numbers, timestamps, and elapsed time.

Events are queued locally and delivered with retryable `fetch` requests to the platform API. Cross-subdomain delivery uses a CORS-safelisted content type so gameplay events are sent as direct POST requests rather than stranded beacon preflights.

Only flat string, number, boolean, or null properties are supported. Do not send personal information.
